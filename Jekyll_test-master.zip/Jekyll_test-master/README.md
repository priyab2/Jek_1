# git-wiki

A github pages / jekyll powered wiki. Readme and demo: (http://drassil.github.io/git-wiki)
